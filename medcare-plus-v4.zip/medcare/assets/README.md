Place app images here before a production build:

- icon.png (1024x1024, no transparency)
- adaptive-icon.png (1024x1024, foreground only)
- splash.png (1284x2778)
- notification-icon.png (96x96, white on transparent)

Then reference them in app.json under expo.icon, expo.splash.image and
expo.android.adaptiveIcon.foregroundImage.
