import * as Location from "expo-location";
import * as SMS from "expo-sms";
import { Linking, Platform } from "react-native";
import type { Contact } from "./types";
import { alertNow } from "./notifications";

export async function getLocationLink(): Promise<string> {
  try {
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== "granted") return "Location unavailable";
    const pos = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
    const { latitude, longitude } = pos.coords;
    return `https://maps.google.com/?q=${latitude.toFixed(6)},${longitude.toFixed(6)}`;
  } catch {
    return "Location unavailable";
  }
}

export function buildSosMessage(userName: string, link: string) {
  return `EMERGENCY from ${userName}. I need help immediately. Live location: ${link} — sent automatically by MedCare+.`;
}

export async function sendSosSms(contacts: Contact[], message: string) {
  const available = await SMS.isAvailableAsync();
  if (!available || contacts.length === 0) return false;
  await SMS.sendSMSAsync(
    contacts.map((c) => c.phone),
    message
  );
  return true;
}

export function callContact(phone: string) {
  const url = Platform.OS === "ios" ? `telprompt:${phone}` : `tel:${phone}`;
  Linking.openURL(url).catch(() => {});
}

export function sendWhatsApp(phone: string, message: string) {
  const digits = phone.replace(/[^0-9]/g, "");
  Linking.openURL(`whatsapp://send?phone=${digits}&text=${encodeURIComponent(message)}`).catch(() => {});
}

export async function triggerFullSos(userName: string, contacts: Contact[]) {
  const link = await getLocationLink();
  const message = buildSosMessage(userName, link);
  await alertNow("SOS sent", "Emergency alert sent to your contacts.");
  await sendSosSms(contacts, message);
  if (contacts[0]) callContact(contacts[0].phone);
  return { message, link };
}
