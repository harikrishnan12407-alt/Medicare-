import * as Notifications from "expo-notifications";
import { Platform } from "react-native";
import type { Medicine } from "./types";

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

export async function initNotifications() {
  const { status } = await Notifications.requestPermissionsAsync();
  if (Platform.OS === "android") {
    await Notifications.setNotificationChannelAsync("medicine", {
      name: "Medicine reminders",
      importance: Notifications.AndroidImportance.MAX,
      sound: "default",
      vibrationPattern: [0, 400, 200, 400],
      bypassDnd: true,
    });
    await Notifications.setNotificationChannelAsync("sos", {
      name: "Emergency alerts",
      importance: Notifications.AndroidImportance.MAX,
      sound: "default",
      vibrationPattern: [0, 800, 200, 800],
      bypassDnd: true,
    });
  }
  return status === "granted";
}

export async function scheduleMedicine(med: Medicine) {
  for (const t of med.times) {
    const [hour, minute] = t.split(":").map(Number);
    await Notifications.scheduleNotificationAsync({
      identifier: `${med.id}-${t}`,
      content: {
        title: "Time for your medicine",
        body: `${med.name} ${med.dose} — ${med.form}`,
        sound: "default",
        data: { medicineId: med.id, time: t },
      },
      trigger: { hour, minute, repeats: true, channelId: "medicine" } as Notifications.NotificationTriggerInput,
    });
  }
}

export async function cancelMedicine(med: Medicine) {
  for (const t of med.times) {
    await Notifications.cancelScheduledNotificationAsync(`${med.id}-${t}`).catch(() => {});
  }
}

export async function rescheduleAll(meds: Medicine[]) {
  await Notifications.cancelAllScheduledNotificationsAsync();
  for (const m of meds) await scheduleMedicine(m);
}

export async function alertNow(title: string, body: string) {
  await Notifications.scheduleNotificationAsync({
    content: { title, body, sound: "default" },
    trigger: null,
  });
}
