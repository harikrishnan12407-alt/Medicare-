import { Accelerometer } from "expo-sensors";

type Sub = { remove: () => void };

/**
 * Free-fall then impact detection.
 * 1. magnitude drops below FREE_FALL_G (weightlessness)
 * 2. within IMPACT_WINDOW_MS magnitude spikes above IMPACT_G
 * 3. followed by ~2s of stillness
 */
const FREE_FALL_G = 0.4;
const IMPACT_G = 2.6;
const IMPACT_WINDOW_MS = 1200;
const STILL_MS = 1800;

export function startFallDetection(onFall: () => void, sensitivity = 1): Sub {
  Accelerometer.setUpdateInterval(60);
  let freeFallAt = 0;
  let impactAt = 0;
  let stillSince = 0;

  const sub = Accelerometer.addListener(({ x, y, z }) => {
    const g = Math.sqrt(x * x + y * y + z * z);
    const now = Date.now();

    if (g < FREE_FALL_G / sensitivity) freeFallAt = now;

    if (!impactAt && freeFallAt && now - freeFallAt < IMPACT_WINDOW_MS && g > IMPACT_G / sensitivity) {
      impactAt = now;
      stillSince = now;
    }

    if (impactAt) {
      if (Math.abs(g - 1) > 0.25) stillSince = now;
      if (now - stillSince > STILL_MS) {
        impactAt = 0;
        freeFallAt = 0;
        onFall();
      }
      if (now - impactAt > 8000) {
        impactAt = 0;
        freeFallAt = 0;
      }
    }
  });

  return { remove: () => sub.remove() };
}
