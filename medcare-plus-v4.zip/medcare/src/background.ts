import * as TaskManager from "expo-task-manager";
import * as BackgroundFetch from "expo-background-fetch";
import { load } from "./storage";
import { rescheduleAll } from "./notifications";

export const BACKGROUND_TASK = "medcare-background-refresh";

// Runs periodically while the app is in the background or closed.
// Re-schedules any medicine reminders that were missed (e.g. after a reboot).
TaskManager.defineTask(BACKGROUND_TASK, async () => {
  try {
    const meds = await load("medicines", []);
    if (Array.isArray(meds) && meds.length > 0) {
      await rescheduleAll(meds);
    }
    return BackgroundFetch.BackgroundFetchResult.NewData;
  } catch {
    return BackgroundFetch.BackgroundFetchResult.Failed;
  }
});

export async function registerBackgroundTask() {
  try {
    const registered = await TaskManager.isTaskRegisteredAsync(BACKGROUND_TASK);
    if (registered) return;
    await BackgroundFetch.registerTaskAsync(BACKGROUND_TASK, {
      minimumInterval: 15 * 60, // every 15 minutes (Android minimum)
      stopOnTerminate: false, // keep running after the app is swiped away
      startOnBoot: true, // restart automatically after phone reboot
    });
  } catch (e) {
    console.warn("Background task registration failed", e);
  }
}
