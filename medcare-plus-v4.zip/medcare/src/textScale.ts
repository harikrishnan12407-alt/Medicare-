import { StyleSheet, Text, TextInput } from "react-native";

// Global text size multiplier (bigger text for older users).
let scale = 1;
export function setTextScale(s: number) {
  scale = s;
}

export function scaleForAge(age: number) {
  if (age >= 60) return 1.3;
  if (age >= 45) return 1.15;
  return 1;
}

export const SIZE_OPTIONS = [
  { label: "Normal", value: 1 },
  { label: "Large", value: 1.15 },
  { label: "Extra Large", value: 1.3 },
  { label: "Huge", value: 1.5 },
];

// Patch Text and TextInput once so every screen grows with the chosen size.
function patch(Comp: any) {
  const orig = Comp.render;
  if (!orig || Comp.__medcarePatched) return;
  Comp.__medcarePatched = true;
  Comp.render = function (props: any, ref: any) {
    if (scale === 1) return orig.call(this, props, ref);
    const flat = StyleSheet.flatten(props.style) || {};
    const fontSize = (flat.fontSize ?? 14) * scale;
    const extra: any = { fontSize };
    if (flat.lineHeight) extra.lineHeight = flat.lineHeight * scale;
    return orig.call(this, { ...props, style: [props.style, extra] }, ref);
  };
}
patch(Text);
patch(TextInput);
