export type Medicine = {
  id: string;
  name: string;
  dose: string;
  form: string;
  times: string[]; // "HH:MM"
  note?: string;
  expiry?: string;
};

export type DoseLog = {
  id: string;
  medicineId: string;
  name: string;
  time: string;
  date: string; // YYYY-MM-DD
  status: "taken" | "missed" | "pending";
};

export type Contact = {
  id: string;
  name: string;
  relation: string;
  phone: string;
};

export type HealthStats = {
  water: number;
  waterGoal: number;
  steps: number;
  stepsGoal: number;
  sleep: string;
  bp: string;
  sugar: string;
};

export type VoiceSettings = {
  language: string;
  languageCode: string;
  voiceType: "Female" | "Male";
  volume: number;
  repeatUntilConfirmed: boolean;
  elderFriendly: boolean;
  offlineVoice: boolean;
};
