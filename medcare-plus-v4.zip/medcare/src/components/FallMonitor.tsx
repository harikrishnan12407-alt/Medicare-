import React, { useEffect, useRef, useState } from "react";
import { Modal, Pressable, StyleSheet, Text, View, Vibration } from "react-native";
import { useApp } from "../store";
import { startFallDetection } from "../fallDetection";
import { triggerFullSos } from "../emergency";
import { speak } from "../voice";
import { alertNow } from "../notifications";
import { theme } from "../theme";
import { startBackgroundFallService, stopBackgroundFallService } from "../backgroundFall";

const COUNTDOWN = 15;

export default function FallMonitor() {
  const { fallDetectionOn, contacts, userName, voice } = useApp();
  const [visible, setVisible] = useState(false);
  const [left, setLeft] = useState(COUNTDOWN);
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (!fallDetectionOn) return;
    const sub = startFallDetection(() => setVisible(true));
    // Keep the app alive in the background so the sensor keeps listening
    startBackgroundFallService();
    return () => {
      sub.remove();
      stopBackgroundFallService();
    };
  }, [fallDetectionOn]);

  useEffect(() => {
    if (!visible) {
      if (timer.current) clearInterval(timer.current);
      setLeft(COUNTDOWN);
      return;
    }
    alertNow("Fall detected!", "Open MedCare+ and tap \"I'm safe\" or help is sent in 15 seconds.").catch(() => {});
    Vibration.vibrate([0, 800, 300, 800, 300, 800], true);
    speak("A fall was detected. Help will be sent automatically in 15 seconds. Tap cancel if you are safe.", voice);
    timer.current = setInterval(() => {
      setLeft((v) => {
        if (v <= 1) {
          clearInterval(timer.current!);
          Vibration.cancel();
          setVisible(false);
          triggerFullSos(userName, contacts);
          return COUNTDOWN;
        }
        return v - 1;
      });
    }, 1000);
    return () => {
      if (timer.current) clearInterval(timer.current);
      Vibration.cancel();
    };
  }, [visible]);

  return (
    <Modal visible={visible} transparent animationType="fade">
      <View style={styles.backdrop}>
        <View style={styles.sheet}>
          <Text style={styles.title}>Fall detected</Text>
          <View style={styles.ring}>
            <Text style={styles.count}>{left}</Text>
            <Text style={styles.sec}>Seconds</Text>
          </View>
          <Text style={styles.sub}>Help will be sent automatically to your emergency contacts.</Text>
          <Pressable style={styles.cancel} onPress={() => setVisible(false)}>
            <Text style={styles.cancelText}>Cancel — I'm safe</Text>
          </Pressable>
          <Pressable
            style={styles.now}
            onPress={() => {
              setVisible(false);
              triggerFullSos(userName, contacts);
            }}
          >
            <Text style={styles.nowText}>Send help now</Text>
          </Pressable>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: { flex: 1, backgroundColor: "#000000CC", alignItems: "center", justifyContent: "center", padding: 24 },
  sheet: {
    width: "100%",
    backgroundColor: theme.card,
    borderRadius: 22,
    borderWidth: 1,
    borderColor: theme.red,
    padding: 22,
    alignItems: "center",
  },
  title: { color: theme.red, fontSize: 20, fontWeight: "800", marginBottom: 18 },
  ring: {
    width: 150,
    height: 150,
    borderRadius: 75,
    borderWidth: 8,
    borderColor: theme.red,
    alignItems: "center",
    justifyContent: "center",
  },
  count: { color: "#fff", fontSize: 44, fontWeight: "900" },
  sec: { color: theme.muted, fontSize: 12 },
  sub: { color: theme.muted, textAlign: "center", marginVertical: 18 },
  cancel: { backgroundColor: theme.cardAlt, paddingVertical: 14, borderRadius: 12, width: "100%", alignItems: "center" },
  cancelText: { color: theme.text, fontWeight: "700" },
  now: { backgroundColor: theme.red, paddingVertical: 14, borderRadius: 12, width: "100%", alignItems: "center", marginTop: 10 },
  nowText: { color: "#fff", fontWeight: "800" },
});
