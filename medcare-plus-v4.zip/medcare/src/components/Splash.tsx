import React, { useEffect, useRef } from "react";
import { Animated, Easing, StyleSheet, Text, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { theme } from "../theme";

export default function Splash({ onDone }: { onDone: () => void }) {
  const scale = useRef(new Animated.Value(0.4)).current;
  const fade = useRef(new Animated.Value(0)).current;
  const pulse = useRef(new Animated.Value(0)).current;
  const text = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.loop(
      Animated.timing(pulse, { toValue: 1, duration: 1400, easing: Easing.out(Easing.quad), useNativeDriver: true })
    ).start();
    Animated.sequence([
      Animated.parallel([
        Animated.spring(scale, { toValue: 1, friction: 5, useNativeDriver: true }),
        Animated.timing(fade, { toValue: 1, duration: 500, useNativeDriver: true }),
      ]),
      Animated.timing(text, { toValue: 1, duration: 600, useNativeDriver: true }),
      Animated.delay(900),
    ]).start(onDone);
  }, []);

  const ringScale = pulse.interpolate({ inputRange: [0, 1], outputRange: [1, 2.2] });
  const ringOpacity = pulse.interpolate({ inputRange: [0, 1], outputRange: [0.5, 0] });

  return (
    <View style={styles.wrap}>
      <View style={styles.glow} />
      <Animated.View style={[styles.ring, { transform: [{ scale: ringScale }], opacity: ringOpacity }]} />
      <Animated.View style={[styles.logo, { opacity: fade, transform: [{ scale }] }]}>
        <Ionicons name="medkit" size={56} color="#fff" />
      </Animated.View>
      <Animated.View style={{ opacity: text, transform: [{ translateY: text.interpolate({ inputRange: [0, 1], outputRange: [20, 0] }) }], alignItems: "center" }}>
        <Text style={styles.title}>
          MedCare<Text style={{ color: theme.green }}>+</Text>
        </Text>
        <Text style={styles.sub}>Your health. Your safety. Always.</Text>
      </Animated.View>
      <Text style={styles.foot}>Medicine reminders • Fall detection • SOS</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: theme.bg, alignItems: "center", justifyContent: "center" },
  glow: { position: "absolute", width: 360, height: 360, borderRadius: 180, backgroundColor: theme.primary, opacity: 0.12 },
  ring: { position: "absolute", width: 120, height: 120, borderRadius: 60, borderWidth: 3, borderColor: theme.primary, top: "50%", marginTop: -110 },
  logo: {
    width: 120, height: 120, borderRadius: 34, backgroundColor: theme.primary,
    alignItems: "center", justifyContent: "center", marginBottom: 26,
    shadowColor: theme.primary, shadowOpacity: 0.8, shadowRadius: 30, elevation: 20,
  },
  title: { color: theme.text, fontSize: 38, fontWeight: "900", letterSpacing: 1 },
  sub: { color: theme.muted, fontSize: 15, marginTop: 8 },
  foot: { position: "absolute", bottom: 48, color: theme.muted, fontSize: 12 },
});
