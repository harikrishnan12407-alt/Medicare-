import React, { useState } from "react";
import { KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useApp } from "../store";
import { SIZE_OPTIONS, scaleForAge, setTextScale } from "../textScale";
import { theme } from "../theme";

export default function Onboarding() {
  const { completeOnboarding } = useApp();
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [size, setSize] = useState<number | null>(null);
  const ageNum = parseInt(age, 10) || 0;
  const chosen = size ?? scaleForAge(ageNum);
  const valid = name.trim().length > 0 && ageNum > 0 && ageNum < 120;

  const pick = (v: number) => {
    setSize(v);
    setTextScale(v);
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: theme.bg }} behavior={Platform.OS === "ios" ? "padding" : undefined}>
      <ScrollView contentContainerStyle={styles.wrap} keyboardShouldPersistTaps="handled">
        <View style={styles.icon}><Ionicons name="person" size={36} color="#fff" /></View>
        <Text style={styles.title}>Welcome to MedCare+</Text>
        <Text style={styles.sub}>Tell us a little about you to get started.</Text>

        <Text style={styles.label}>Your name</Text>
        <TextInput value={name} onChangeText={setName} placeholder="Enter your name" placeholderTextColor={theme.muted} style={styles.input} />

        <Text style={styles.label}>Your age</Text>
        <TextInput value={age} onChangeText={(t) => setAge(t.replace(/[^0-9]/g, ""))} keyboardType="number-pad" maxLength={3} placeholder="e.g. 65" placeholderTextColor={theme.muted} style={styles.input} />

        <Text style={styles.label}>Text size</Text>
        <Text style={styles.hint}>{ageNum ? "Suggested for your age — you can change it anytime in Profile." : "Enter your age for a suggestion."}</Text>
        <View style={styles.chips}>
          {SIZE_OPTIONS.map((o) => (
            <Pressable key={o.value} onPress={() => pick(o.value)} style={[styles.chip, chosen === o.value && styles.chipOn]}>
              <Text style={{ color: theme.text, fontWeight: "700", fontSize: 13 * o.value }}>Aa</Text>
              <Text style={{ color: theme.muted, fontSize: 11 }}>{o.label}</Text>
            </Pressable>
          ))}
        </View>

        <Pressable disabled={!valid} onPress={() => completeOnboarding(name.trim(), ageNum, chosen)} style={[styles.btn, !valid && { opacity: 0.4 }]}>
          <Text style={styles.btnText}>Get started</Text>
          <Ionicons name="arrow-forward" size={18} color="#fff" />
        </Pressable>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  wrap: { padding: 24, paddingTop: 70 },
  icon: { width: 72, height: 72, borderRadius: 22, backgroundColor: theme.primary, alignItems: "center", justifyContent: "center", alignSelf: "center", marginBottom: 18 },
  title: { color: theme.text, fontSize: 26, fontWeight: "900", textAlign: "center" },
  sub: { color: theme.muted, textAlign: "center", marginTop: 6, marginBottom: 28 },
  label: { color: theme.text, fontWeight: "700", marginBottom: 8, marginTop: 14 },
  hint: { color: theme.muted, fontSize: 12, marginBottom: 10 },
  input: { backgroundColor: theme.card, borderWidth: 1, borderColor: theme.border, borderRadius: 12, padding: 14, color: theme.text, fontSize: 16 },
  chips: { flexDirection: "row", gap: 8 },
  chip: { flex: 1, alignItems: "center", paddingVertical: 12, borderRadius: 12, borderWidth: 1, borderColor: theme.border, backgroundColor: theme.card },
  chipOn: { borderColor: theme.primary, backgroundColor: theme.cardAlt },
  btn: { marginTop: 32, backgroundColor: theme.green, borderRadius: 14, paddingVertical: 16, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8 },
  btnText: { color: "#fff", fontWeight: "800", fontSize: 16 },
});
