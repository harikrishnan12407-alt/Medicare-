import React, { createContext, useContext, useEffect, useMemo, useState } from "react";
import { load, save } from "./storage";
import { SEED_CONTACTS, SEED_HEALTH, SEED_MEDICINES, SEED_VOICE } from "./seed";
import type { Contact, DoseLog, HealthStats, Medicine, VoiceSettings } from "./types";
import { initNotifications, rescheduleAll } from "./notifications";
import { setTextScale } from "./textScale";

const today = () => new Date().toISOString().slice(0, 10);

type Ctx = {
  ready: boolean;
  userName: string;
  setUserName: (n: string) => void;
  age: number;
  setAge: (a: number) => void;
  textScale: number;
  setTextScaleValue: (s: number) => void;
  onboarded: boolean;
  completeOnboarding: (name: string, age: number, scale: number) => void;
  medicines: Medicine[];
  addMedicine: (m: Omit<Medicine, "id">) => void;
  removeMedicine: (id: string) => void;
  logs: DoseLog[];
  markDose: (medicineId: string, time: string, status: "taken" | "missed") => void;
  doseStatus: (medicineId: string, time: string) => "taken" | "missed" | "pending";
  contacts: Contact[];
  addContact: (c: Omit<Contact, "id">) => void;
  removeContact: (id: string) => void;
  health: HealthStats;
  setHealth: (h: HealthStats) => void;
  voice: VoiceSettings;
  setVoice: (v: VoiceSettings) => void;
  fallDetectionOn: boolean;
  setFallDetectionOn: (v: boolean) => void;
};

const AppCtx = createContext<Ctx | null>(null);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [ready, setReady] = useState(false);
  const [userName, setUserName] = useState("");
  const [age, setAge] = useState(0);
  const [textScale, setTextScaleValue] = useState(1);
  const [onboarded, setOnboarded] = useState(false);
  const [medicines, setMedicines] = useState<Medicine[]>(SEED_MEDICINES);
  const [logs, setLogs] = useState<DoseLog[]>([]);
  const [contacts, setContacts] = useState<Contact[]>(SEED_CONTACTS);
  const [health, setHealth] = useState<HealthStats>(SEED_HEALTH);
  const [voice, setVoice] = useState<VoiceSettings>(SEED_VOICE);
  const [fallDetectionOn, setFallDetectionOn] = useState(true);

  useEffect(() => {
    (async () => {
      setUserName(await load("userName", ""));
      setAge(await load("age", 0));
      const sc = await load("textScale", 1);
      setTextScale(sc);
      setTextScaleValue(sc);
      setOnboarded(await load("onboarded", false));
      const meds = await load("medicines", SEED_MEDICINES);
      setMedicines(meds);
      setLogs(await load<DoseLog[]>("logs", []));
      setContacts(await load("contacts", SEED_CONTACTS));
      setHealth(await load("health", SEED_HEALTH));
      setVoice(await load("voice", SEED_VOICE));
      setFallDetectionOn(await load("fallDetectionOn", true));
      setReady(true);
      const granted = await initNotifications();
      if (granted) await rescheduleAll(meds);
    })();
  }, []);

  useEffect(() => { if (ready) save("userName", userName); }, [userName, ready]);
  useEffect(() => { if (ready) { save("medicines", medicines); rescheduleAll(medicines); } }, [medicines, ready]);
  useEffect(() => { if (ready) save("age", age); }, [age, ready]);
  useEffect(() => { setTextScale(textScale); if (ready) save("textScale", textScale); }, [textScale, ready]);
  useEffect(() => { if (ready) save("onboarded", onboarded); }, [onboarded, ready]);
  useEffect(() => { if (ready) save("logs", logs); }, [logs, ready]);
  useEffect(() => { if (ready) save("contacts", contacts); }, [contacts, ready]);
  useEffect(() => { if (ready) save("health", health); }, [health, ready]);
  useEffect(() => { if (ready) save("voice", voice); }, [voice, ready]);
  useEffect(() => { if (ready) save("fallDetectionOn", fallDetectionOn); }, [fallDetectionOn, ready]);

  const value = useMemo<Ctx>(
    () => ({
      ready,
      userName,
      setUserName,
      age,
      setAge,
      textScale,
      setTextScaleValue,
      onboarded,
      completeOnboarding: (name, a, scale) => {
        setUserName(name);
        setAge(a);
        setTextScale(scale);
        setTextScaleValue(scale);
        setOnboarded(true);
      },
      medicines,
      addMedicine: (m) => setMedicines((prev) => [...prev, { ...m, id: `m${Date.now()}` }]),
      removeMedicine: (id) => setMedicines((prev) => prev.filter((x) => x.id !== id)),
      logs,
      markDose: (medicineId, time, status) =>
        setLogs((prev) => {
          const med = medicines.find((m) => m.id === medicineId);
          const date = today();
          const rest = prev.filter((l) => !(l.medicineId === medicineId && l.time === time && l.date === date));
          return [
            { id: `${medicineId}-${time}-${date}`, medicineId, name: med?.name ?? "Medicine", time, date, status },
            ...rest,
          ];
        }),
      doseStatus: (medicineId, time) =>
        logs.find((l) => l.medicineId === medicineId && l.time === time && l.date === today())?.status ?? "pending",
      contacts,
      addContact: (c) => setContacts((prev) => [...prev, { ...c, id: `c${Date.now()}` }]),
      removeContact: (id) => setContacts((prev) => prev.filter((x) => x.id !== id)),
      health,
      setHealth,
      voice,
      setVoice,
      fallDetectionOn,
      setFallDetectionOn,
    }),
    [ready, userName, age, textScale, onboarded, medicines, logs, contacts, health, voice, fallDetectionOn]
  );

  return <AppCtx.Provider value={value}>{children}</AppCtx.Provider>;
}

export function useApp() {
  const ctx = useContext(AppCtx);
  if (!ctx) throw new Error("useApp must be used inside AppProvider");
  return ctx;
}
