import * as Speech from "expo-speech";
import type { VoiceSettings } from "./types";

export function speak(text: string, settings: VoiceSettings) {
  Speech.stop();
  Speech.speak(text, {
    language: settings.languageCode,
    rate: settings.elderFriendly ? 0.82 : 1.0,
    pitch: settings.voiceType === "Female" ? 1.1 : 0.85,
    volume: Math.min(1, settings.volume / 100),
  });
}

export function stopSpeaking() {
  Speech.stop();
}

export async function repeatUntilConfirmed(
  text: string,
  settings: VoiceSettings,
  isConfirmed: () => boolean,
  maxRepeats = 5
) {
  for (let i = 0; i < maxRepeats; i++) {
    if (isConfirmed()) return;
    speak(text, settings);
    await new Promise((r) => setTimeout(r, 12000));
  }
}
