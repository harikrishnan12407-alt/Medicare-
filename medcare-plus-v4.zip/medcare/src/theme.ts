export const theme = {
  bg: "#060B1F",
  card: "#101935",
  cardAlt: "#16224A",
  border: "#22305C",
  text: "#EAF0FF",
  muted: "#9AA8CC",
  primary: "#2F6BFF",
  green: "#12B981",
  red: "#EF3B44",
  purple: "#7C3AED",
  amber: "#F59E0B",
  radius: 16,
};

export const shadow = {
  shadowColor: "#000",
  shadowOpacity: 0.3,
  shadowRadius: 12,
  shadowOffset: { width: 0, height: 6 },
  elevation: 5,
};
