import * as Location from "expo-location";
import * as TaskManager from "expo-task-manager";

// A persistent "MedCare+ is protecting you" notification (Android foreground
// service) keeps the app alive when minimised or the screen is off, so the
// fall sensor keeps listening in the background.
export const FALL_KEEPALIVE_TASK = "medcare-fall-keepalive";

TaskManager.defineTask(FALL_KEEPALIVE_TASK, async () => {
  // Nothing to do — the running service itself keeps fall detection alive.
});

export async function startBackgroundFallService() {
  try {
    const fg = await Location.requestForegroundPermissionsAsync();
    if (fg.status !== "granted") return;
    const bg = await Location.requestBackgroundPermissionsAsync();
    if (bg.status !== "granted") return;
    if (await Location.hasStartedLocationUpdatesAsync(FALL_KEEPALIVE_TASK)) return;
    await Location.startLocationUpdatesAsync(FALL_KEEPALIVE_TASK, {
      accuracy: Location.Accuracy.Balanced,
      timeInterval: 60_000,
      distanceInterval: 50,
      pausesUpdatesAutomatically: false,
      showsBackgroundLocationIndicator: false,
      foregroundService: {
        notificationTitle: "MedCare+ fall detection is on",
        notificationBody: "Watching for falls in the background to keep you safe.",
        notificationColor: "#2F6BFF",
        killServiceOnDestroy: false,
      },
    });
  } catch (e) {
    console.warn("Background fall service failed", e);
  }
}

export async function stopBackgroundFallService() {
  try {
    if (await Location.hasStartedLocationUpdatesAsync(FALL_KEEPALIVE_TASK)) {
      await Location.stopLocationUpdatesAsync(FALL_KEEPALIVE_TASK);
    }
  } catch {}
}
