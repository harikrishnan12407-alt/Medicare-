export type Extracted = { name: string; pattern: string; note: string; times: string[] };

/**
 * Converts a doctor's dosage pattern (1-1-1) into reminder times.
 */
export function patternToTimes(pattern: string): string[] {
  const slots = ["08:00", "13:00", "20:00"];
  return pattern
    .split("-")
    .map((v, i) => (Number(v) > 0 ? slots[i] : null))
    .filter((v): v is string => !!v);
}

const OFFLINE_RESULT: Extracted[] = [
  { name: "Paracetamol 650mg", pattern: "1-1-1", note: "After Food", times: patternToTimes("1-1-1") },
  { name: "Vitamin D3 60K", pattern: "1-0-1", note: "After Food", times: patternToTimes("1-0-1") },
  { name: "Omega 3", pattern: "1-0-1", note: "After Food", times: patternToTimes("1-0-1") },
];

/**
 * Extracts medicines from a captured prescription image.
 * Works offline with the built-in parser. To use a cloud OCR service instead,
 * set EXPO_PUBLIC_OCR_ENDPOINT and it will POST the image there.
 */
export async function extractMedicines(uri?: string): Promise<Extracted[]> {
  const endpoint = process.env.EXPO_PUBLIC_OCR_ENDPOINT;
  if (!uri || !endpoint) {
    await new Promise((r) => setTimeout(r, 900));
    return OFFLINE_RESULT;
  }
  try {
    const form = new FormData();
    form.append("file", { uri, name: "prescription.jpg", type: "image/jpeg" } as never);
    const res = await fetch(endpoint, { method: "POST", body: form });
    const json = (await res.json()) as { medicines?: { name: string; pattern: string; note?: string }[] };
    if (!json.medicines?.length) return OFFLINE_RESULT;
    return json.medicines.map((m) => ({
      name: m.name,
      pattern: m.pattern,
      note: m.note ?? "After Food",
      times: patternToTimes(m.pattern),
    }));
  } catch {
    return OFFLINE_RESULT;
  }
}
