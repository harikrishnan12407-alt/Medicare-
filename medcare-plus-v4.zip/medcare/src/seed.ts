import type { Contact, HealthStats, Medicine, VoiceSettings } from "./types";

export const SEED_MEDICINES: Medicine[] = [];

export const SEED_CONTACTS: Contact[] = [];

export const SEED_HEALTH: HealthStats = {
  water: 0,
  waterGoal: 8,
  steps: 0,
  stepsGoal: 10000,
  sleep: "—",
  bp: "—",
  sugar: "—",
};

export const SEED_VOICE: VoiceSettings = {
  language: "Tamil",
  languageCode: "ta-IN",
  voiceType: "Female",
  volume: 150,
  repeatUntilConfirmed: true,
  elderFriendly: true,
  offlineVoice: true,
};
