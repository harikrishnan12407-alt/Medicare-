export const MEDICINE_DB = [
  { barcode: "8901234567890", brand: "Dolo-650", name: "Paracetamol 650mg", form: "Tablet", expiry: "12/2026" },
  { barcode: "8909876543210", brand: "Calcirol D3", name: "Vitamin D3 60K", form: "Capsule", expiry: "08/2027" },
  { barcode: "8905551112223", brand: "Seacod", name: "Omega 3", form: "Capsule", expiry: "03/2027" },
  { barcode: "8901112223334", brand: "Metformin SR", name: "Metformin 500mg", form: "Tablet", expiry: "10/2026" },
] as const;

export function lookupByBarcode(code: string) {
  const hit = MEDICINE_DB.find((m) => m.barcode === code);
  if (hit) return hit;
  // Deterministic fallback so an unknown strip still produces a usable entry.
  const index = Math.abs([...code].reduce((a, c) => a + c.charCodeAt(0), 0)) % MEDICINE_DB.length;
  return MEDICINE_DB[index];
}
