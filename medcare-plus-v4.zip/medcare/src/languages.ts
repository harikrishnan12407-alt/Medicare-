export type Lang = { label: string; native: string; code: string; sample: (m: string) => string };

export const LANGUAGES: Lang[] = [
  {
    label: "Tamil",
    native: "தமிழ்",
    code: "ta-IN",
    sample: (m) => `வணக்கம்! காலை 8 மணி ஆகிவிட்டது. ${m} ஒரு மாத்திரை எடுத்துக்கொள்ள வேண்டிய நேரம்.`,
  },
  { label: "English", native: "English", code: "en-IN", sample: (m) => `Good morning! It's 8:00 AM. Time to take one ${m} tablet.` },
  { label: "Hindi", native: "हिंदी", code: "hi-IN", sample: (m) => `सुप्रभात! सुबह के 8 बज गए हैं। ${m} की एक गोली लेने का समय है।` },
  { label: "Telugu", native: "తెలుగు", code: "te-IN", sample: (m) => `శుభోదయం! ఉదయం 8 గంటలు. ${m} ఒక మాత్ర తీసుకునే సమయం.` },
  { label: "Malayalam", native: "മലയാളം", code: "ml-IN", sample: (m) => `സുപ്രഭാതം! രാവിലെ 8 മണി. ${m} ഒരു ഗുളിക കഴിക്കേണ്ട സമയമായി.` },
  { label: "Kannada", native: "ಕನ್ನಡ", code: "kn-IN", sample: (m) => `ಶುಭೋದಯ! ಬೆಳಿಗ್ಗೆ 8 ಗಂಟೆ. ${m} ಒಂದು ಮಾತ್ರೆ ತೆಗೆದುಕೊಳ್ಳುವ ಸಮಯ.` },
  { label: "Bengali", native: "বাংলা", code: "bn-IN", sample: (m) => `সুপ্রভাত! সকাল ৮টা বাজে। ${m} একটি ট্যাবলেট নেওয়ার সময়।` },
  { label: "Marathi", native: "मराठी", code: "mr-IN", sample: (m) => `सुप्रभात! सकाळचे ८ वाजले आहेत. ${m} ची एक गोळी घेण्याची वेळ झाली आहे.` },
  { label: "Gujarati", native: "ગુજરાતી", code: "gu-IN", sample: (m) => `સુપ્રભાત! સવારના 8 વાગ્યા છે. ${m} ની એક ગોળી લેવાનો સમય છે.` },
  { label: "Punjabi", native: "ਪੰਜਾਬੀ", code: "pa-IN", sample: (m) => `ਸ਼ੁਭ ਸਵੇਰ! ਸਵੇਰ ਦੇ 8 ਵੱਜ ਗਏ ਹਨ। ${m} ਦੀ ਇੱਕ ਗੋਲੀ ਲੈਣ ਦਾ ਸਮਾਂ ਹੈ।` },
  { label: "Urdu", native: "اردو", code: "ur-IN", sample: (m) => `صبح بخیر! صبح کے 8 بج گئے ہیں۔ ${m} کی ایک گولی لینے کا وقت ہے۔` },
  { label: "Odia", native: "ଓଡ଼ିଆ", code: "or-IN", sample: (m) => `ଶୁଭ ସକାଳ! ସକାଳ ୮ଟା ବାଜିଲାଣି। ${m} ଏକ ଟାବଲେଟ ନେବାର ସମୟ।` },
];
