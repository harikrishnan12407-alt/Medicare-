import "../src/textScale";
import { Stack } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { View } from "react-native";
import { AppProvider, useApp } from "../src/store";
import FallMonitor from "../src/components/FallMonitor";
import Splash from "../src/components/Splash";
import Onboarding from "../src/components/Onboarding";
import { registerBackgroundTask } from "../src/background";
import "../src/backgroundFall";
import { theme } from "../src/theme";
import { useEffect, useState } from "react";

function Root() {
  const { ready, onboarded, textScale } = useApp();
  const [splashDone, setSplashDone] = useState(false);

  if (!splashDone || !ready) return <Splash onDone={() => setSplashDone(true)} />;
  if (!onboarded) return <Onboarding />;

  return (
    <View style={{ flex: 1, backgroundColor: theme.bg }} key={`scale-${textScale}`}>
      <FallMonitor />
      <Stack
        screenOptions={{
          headerStyle: { backgroundColor: theme.bg },
          headerTintColor: theme.text,
          contentStyle: { backgroundColor: theme.bg },
        }}
      >
        <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
        <Stack.Screen name="sos" options={{ title: "SOS Emergency", presentation: "modal" }} />
        <Stack.Screen name="scanner" options={{ title: "Medicine Scanner" }} />
        <Stack.Screen name="prescription" options={{ title: "Prescription Scan" }} />
        <Stack.Screen name="fall" options={{ title: "Fall Detection" }} />
        <Stack.Screen name="contacts" options={{ title: "Family & Emergency Contacts" }} />
        <Stack.Screen name="add-medicine" options={{ title: "Add Medicine" }} />
        <Stack.Screen name="voice" options={{ title: "Voice Reminder" }} />
        <Stack.Screen name="reports" options={{ title: "Reports" }} />
      </Stack>
    </View>
  );
}

export default function RootLayout() {
  useEffect(() => {
    registerBackgroundTask();
  }, []);

  return (
    <SafeAreaProvider>
      <AppProvider>
        <StatusBar style="light" />
        <Root />
      </AppProvider>
    </SafeAreaProvider>
  );
}
