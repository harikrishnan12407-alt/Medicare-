import React, { useEffect, useState } from "react";
import { ScrollView, StyleSheet, Switch, Text, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { Accelerometer } from "expo-sensors";
import { useApp } from "../src/store";
import { Button, Card } from "../src/components/UI";
import { theme } from "../src/theme";
import { triggerFullSos } from "../src/emergency";

export default function Fall() {
  const { fallDetectionOn, setFallDetectionOn, contacts, userName } = useApp();
  const [g, setG] = useState(1);

  useEffect(() => {
    Accelerometer.setUpdateInterval(200);
    const sub = Accelerometer.addListener(({ x, y, z }) => setG(Math.sqrt(x * x + y * y + z * z)));
    return () => sub.remove();
  }, []);

  return (
    <ScrollView style={{ backgroundColor: theme.bg }} contentContainerStyle={{ padding: 16 }}>
      <Card>
        <View style={styles.row}>
          <Text style={styles.title}>Fall Detection</Text>
          <Switch value={fallDetectionOn} onValueChange={setFallDetectionOn} trackColor={{ true: theme.green }} />
        </View>
        <Text style={styles.body}>Monitoring your safety 24/7 using the phone's motion sensors.</Text>
      </Card>

      <Card style={{ alignItems: "center", borderColor: fallDetectionOn ? theme.green : theme.border }}>
        <Ionicons name={fallDetectionOn ? "shield-checkmark" : "shield-outline"} size={44} color={fallDetectionOn ? theme.green : theme.muted} />
        <Text style={[styles.title, { marginTop: 10 }]}>{fallDetectionOn ? "No fall detected" : "Monitoring paused"}</Text>
        <Text style={styles.body}>{fallDetectionOn ? "You are safe" : "Turn it on to stay protected"}</Text>
        <Text style={[styles.body, { marginTop: 8 }]}>Live motion: {g.toFixed(2)} g</Text>
      </Card>

      <Card>
        <Text style={styles.title}>When a fall is detected</Text>
        {[
          ["volume-high", "High alert sound"],
          ["time", "15 second countdown"],
          ["call", "Instant SOS call"],
          ["navigate", "Live location SMS"],
          ["logo-whatsapp", "WhatsApp alert"],
          ["people", "Alert to all contacts"],
        ].map(([icon, label]) => (
          <View key={label} style={styles.listRow}>
            <Ionicons name={icon as never} size={18} color={theme.red} />
            <Text style={styles.item}>{label}</Text>
          </View>
        ))}
        <View style={{ height: 12 }} />
        <Button label="Send Help Now" color={theme.red} icon="alert-circle" onPress={() => triggerFullSos(userName, contacts)} />
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  title: { color: theme.text, fontWeight: "800", fontSize: 16 },
  body: { color: theme.muted, fontSize: 13, marginTop: 4, textAlign: "center" },
  listRow: { flexDirection: "row", alignItems: "center", gap: 10, paddingVertical: 8 },
  item: { color: theme.text, fontSize: 14, fontWeight: "600" },
});
