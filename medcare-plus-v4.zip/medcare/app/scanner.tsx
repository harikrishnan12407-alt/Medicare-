import React, { useState } from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { CameraView, useCameraPermissions } from "expo-camera";
import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useApp } from "../src/store";
import { Button, Card } from "../src/components/UI";
import { theme } from "../src/theme";
import { speak } from "../src/voice";
import { MEDICINE_DB, lookupByBarcode } from "../src/medicineDb";

export default function Scanner() {
  const [permission, requestPermission] = useCameraPermissions();
  const [detected, setDetected] = useState<(typeof MEDICINE_DB)[number] | null>(null);
  const { addMedicine, voice } = useApp();
  const router = useRouter();

  if (!permission?.granted) {
    return (
      <View style={styles.center}>
        <Ionicons name="camera-outline" size={48} color={theme.muted} />
        <Text style={styles.body}>Camera access is needed to scan a medicine strip or bottle.</Text>
        <Button label="Allow camera" onPress={requestPermission} />
      </View>
    );
  }

  return (
    <ScrollView style={{ backgroundColor: theme.bg }} contentContainerStyle={{ padding: 16 }}>
      <Card>
        <Text style={styles.title}>Medicine Scanner</Text>
        <Text style={styles.body}>Point the camera at the barcode on the strip or bottle.</Text>
        <View style={styles.camWrap}>
          <CameraView
            style={{ flex: 1 }}
            barcodeScannerSettings={{ barcodeTypes: ["ean13", "ean8", "code128", "upc_a", "qr"] }}
            onBarcodeScanned={({ data }) => {
              if (detected) return;
              const found = lookupByBarcode(data);
              setDetected(found);
              speak(`Detected ${found.brand}, ${found.name}.`, voice);
            }}
          />
        </View>
      </Card>

      {detected ? (
        <Card style={{ borderColor: theme.green }}>
          <Text style={styles.label}>Detected Medicine</Text>
          <Text style={styles.brand}>{detected.brand}</Text>
          <Text style={styles.body}>{detected.name}</Text>
          <Text style={styles.body}>{detected.form} · Expiry {detected.expiry}</Text>
          <View style={{ height: 12 }} />
          <Button
            label="Add to Schedule"
            onPress={() => {
              addMedicine({ name: detected.name, dose: `1 ${detected.form}`, form: detected.form, times: ["08:00"], expiry: detected.expiry });
              router.replace("/");
            }}
          />
          <View style={{ height: 8 }} />
          <Pressable onPress={() => setDetected(null)}>
            <Text style={styles.again}>Scan another</Text>
          </Pressable>
        </Card>
      ) : null}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, backgroundColor: theme.bg, alignItems: "center", justifyContent: "center", padding: 24, gap: 14 },
  title: { color: theme.text, fontWeight: "800", fontSize: 16 },
  body: { color: theme.muted, fontSize: 13, textAlign: "center", marginTop: 4 },
  camWrap: { height: 280, borderRadius: 14, overflow: "hidden", marginTop: 12, backgroundColor: "#000" },
  label: { color: theme.muted, fontSize: 12 },
  brand: { color: theme.green, fontSize: 22, fontWeight: "800", marginVertical: 4 },
  again: { color: theme.primary, textAlign: "center", fontWeight: "600" },
});
