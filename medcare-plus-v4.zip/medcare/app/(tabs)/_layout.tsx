import { Tabs, useRouter } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { theme } from "../../src/theme";

function SosButton() {
  const router = useRouter();
  return (
    <Pressable style={styles.sosWrap} onPress={() => router.push("/sos")}>
      <View style={styles.sos}>
        <Text style={styles.sosText}>SOS</Text>
      </View>
    </Pressable>
  );
}

export default function TabsLayout() {
  return (
    <Tabs
      screenOptions={{
        headerStyle: { backgroundColor: theme.bg },
        headerTintColor: theme.text,
        tabBarStyle: { backgroundColor: theme.card, borderTopColor: theme.border, height: 64, paddingBottom: 8 },
        tabBarActiveTintColor: theme.primary,
        tabBarInactiveTintColor: theme.muted,
      }}
    >
      <Tabs.Screen
        name="index"
        options={{ title: "Home", headerShown: false, tabBarIcon: ({ color, size }) => <Ionicons name="home" color={color} size={size} /> }}
      />
      <Tabs.Screen
        name="history"
        options={{ title: "History", tabBarIcon: ({ color, size }) => <Ionicons name="time-outline" color={color} size={size} /> }}
      />
      <Tabs.Screen
        name="sos-tab"
        options={{ title: "", tabBarButton: () => <SosButton /> }}
      />
      <Tabs.Screen
        name="health"
        options={{ title: "Health", tabBarIcon: ({ color, size }) => <Ionicons name="heart-outline" color={color} size={size} /> }}
      />
      <Tabs.Screen
        name="profile"
        options={{ title: "Profile", tabBarIcon: ({ color, size }) => <Ionicons name="person-outline" color={color} size={size} /> }}
      />
    </Tabs>
  );
}

const styles = StyleSheet.create({
  sosWrap: { flex: 1, alignItems: "center", justifyContent: "center" },
  sos: {
    width: 58,
    height: 58,
    borderRadius: 29,
    backgroundColor: theme.red,
    alignItems: "center",
    justifyContent: "center",
    marginTop: -22,
    borderWidth: 4,
    borderColor: theme.bg,
  },
  sosText: { color: "#fff", fontWeight: "900", fontSize: 15 },
});
