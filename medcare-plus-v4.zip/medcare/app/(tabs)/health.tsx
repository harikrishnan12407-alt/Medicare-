import React from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useApp } from "../../src/store";
import { Card, SectionTitle } from "../../src/components/UI";
import { theme } from "../../src/theme";

export default function Health() {
  const { health, setHealth } = useApp();
  const router = useRouter();

  const rows = [
    { icon: "water", color: theme.primary, label: "Water Reminder", value: `${health.water}/${health.waterGoal} Glasses` },
    { icon: "footsteps", color: theme.amber, label: "Steps", value: `${health.steps.toLocaleString()} / ${health.stepsGoal.toLocaleString()}` },
    { icon: "moon", color: theme.purple, label: "Sleep", value: health.sleep },
    { icon: "heart", color: theme.red, label: "Blood Pressure", value: health.bp },
    { icon: "water-outline", color: theme.green, label: "Blood Sugar", value: health.sugar },
  ] as const;

  return (
    <ScrollView style={{ backgroundColor: theme.bg }} contentContainerStyle={{ padding: 16 }}>
      <SectionTitle title="Health Dashboard" />
      <Card>
        {rows.map((r, i) => (
          <View key={r.label} style={[styles.row, i > 0 && styles.divider]}>
            <View style={[styles.icon, { backgroundColor: r.color + "22" }]}>
              <Ionicons name={r.icon as never} size={18} color={r.color} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.label}>{r.label}</Text>
              <Text style={styles.value}>{r.value}</Text>
            </View>
          </View>
        ))}
      </Card>

      <Pressable
        style={styles.action}
        onPress={() => setHealth({ ...health, water: Math.min(health.waterGoal, health.water + 1) })}
      >
        <Ionicons name="add" size={18} color="#fff" />
        <Text style={styles.actionText}>Log a glass of water</Text>
      </Pressable>

      <View style={{ height: 14 }} />
      <Pressable style={[styles.action, { backgroundColor: theme.purple }]} onPress={() => router.push("/reports")}>
        <Ionicons name="bar-chart" size={18} color="#fff" />
        <Text style={styles.actionText}>View monthly reports</Text>
      </Pressable>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: "row", alignItems: "center", gap: 12, paddingVertical: 12 },
  divider: { borderTopWidth: 1, borderTopColor: theme.border },
  icon: { width: 36, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  label: { color: theme.text, fontWeight: "700", fontSize: 14 },
  value: { color: theme.muted, fontSize: 12, marginTop: 2 },
  action: {
    flexDirection: "row",
    gap: 8,
    backgroundColor: theme.primary,
    padding: 14,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  actionText: { color: "#fff", fontWeight: "700" },
});
