import { Redirect } from "expo-router";

// Placeholder route: the center tab button navigates to the /sos modal.
export default function SosTab() {
  return <Redirect href="/sos" />;
}
