import React, { useMemo, useState } from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { useApp } from "../../src/store";
import { Card, Pill } from "../../src/components/UI";
import { theme } from "../../src/theme";

const FILTERS = ["All", "Taken", "Missed"] as const;

export default function History() {
  const { logs } = useApp();
  const [filter, setFilter] = useState<(typeof FILTERS)[number]>("All");

  const grouped = useMemo(() => {
    const filtered = logs.filter((l) => filter === "All" || l.status === filter.toLowerCase());
    const byDate: Record<string, typeof filtered> = {};
    for (const l of filtered) (byDate[l.date] ||= []).push(l);
    return Object.entries(byDate).sort((a, b) => b[0].localeCompare(a[0]));
  }, [logs, filter]);

  const today = new Date().toISOString().slice(0, 10);

  return (
    <ScrollView style={{ backgroundColor: theme.bg }} contentContainerStyle={{ padding: 16 }}>
      <View style={styles.tabs}>
        {FILTERS.map((f) => (
          <Pressable key={f} onPress={() => setFilter(f)} style={[styles.tab, filter === f && styles.tabActive]}>
            <Text style={[styles.tabText, filter === f && { color: "#fff" }]}>{f}</Text>
          </Pressable>
        ))}
      </View>

      {grouped.length === 0 ? (
        <Card>
          <Text style={{ color: theme.muted }}>No doses recorded yet. Mark a dose on the home screen.</Text>
        </Card>
      ) : null}

      {grouped.map(([date, items]) => (
        <View key={date}>
          <Text style={styles.date}>{date === today ? "Today" : date}</Text>
          <Card>
            {items.map((l, i) => (
              <View key={l.id} style={[styles.row, i > 0 && styles.divider]}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.time}>{l.time}</Text>
                  <Text style={styles.name}>{l.name}</Text>
                </View>
                <Pill text={l.status === "taken" ? "Taken" : "Missed"} color={l.status === "taken" ? theme.green : theme.red} />
              </View>
            ))}
          </Card>
        </View>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  tabs: { flexDirection: "row", backgroundColor: theme.card, borderRadius: 12, padding: 4, marginBottom: 16 },
  tab: { flex: 1, paddingVertical: 9, borderRadius: 9, alignItems: "center" },
  tabActive: { backgroundColor: theme.green },
  tabText: { color: theme.muted, fontWeight: "700", fontSize: 13 },
  date: { color: theme.muted, marginBottom: 8, fontWeight: "600" },
  row: { flexDirection: "row", alignItems: "center", paddingVertical: 12 },
  divider: { borderTopWidth: 1, borderTopColor: theme.border },
  time: { color: theme.text, fontWeight: "700", fontSize: 13 },
  name: { color: theme.muted, fontSize: 13 },
});
