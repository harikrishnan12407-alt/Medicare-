import React, { useMemo } from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { SafeAreaView } from "react-native-safe-area-context";
import { useApp } from "../../src/store";
import { Button, Card, SectionTitle } from "../../src/components/UI";
import { theme } from "../../src/theme";
import { LANGUAGES } from "../../src/languages";
import { speak } from "../../src/voice";

const QUICK = [
  { label: "Medicine\nReminder", icon: "medkit", color: theme.primary, href: "/add-medicine" },
  { label: "Prescription\nScan", icon: "document-text", color: theme.green, href: "/prescription" },
  { label: "Medicine\nScanner", icon: "camera", color: theme.amber, href: "/scanner" },
  { label: "Fall\nDetection", icon: "walk", color: theme.purple, href: "/fall" },
  { label: "SOS\nEmergency", icon: "alert-circle", color: theme.red, href: "/sos" },
] as const;

function fmt(t: string) {
  const [h, m] = t.split(":").map(Number);
  const ap = h >= 12 ? "PM" : "AM";
  const hh = h % 12 === 0 ? 12 : h % 12;
  return `${String(hh).padStart(2, "0")}:${String(m).padStart(2, "0")} ${ap}`;
}

export default function Home() {
  const router = useRouter();
  const { userName, medicines, markDose, doseStatus, voice } = useApp();

  const schedule = useMemo(
    () =>
      medicines
        .flatMap((m) => m.times.map((t) => ({ med: m, time: t })))
        .sort((a, b) => a.time.localeCompare(b.time)),
    [medicines]
  );

  const next = schedule.find((s) => doseStatus(s.med.id, s.time) === "pending") ?? schedule[0];

  const announce = () => {
    if (!next) return;
    const lang = LANGUAGES.find((l) => l.label === voice.language) ?? LANGUAGES[1];
    speak(lang.sample(next.med.name), voice);
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: theme.bg }} edges={["top"]}>
      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 30 }}>
        <View style={styles.header}>
          <View>
            <Text style={styles.hello}>Good Morning</Text>
            <Text style={styles.name}>{userName} 👋</Text>
          </View>
          <Pressable onPress={() => router.push("/voice")} hitSlop={10}>
            <Ionicons name="notifications-outline" size={26} color={theme.text} />
          </Pressable>
        </View>

        {next ? (
          <Card style={{ backgroundColor: theme.cardAlt }}>
            <View style={styles.rowBetween}>
              <Text style={styles.muted}>Next Medicine</Text>
              <Text style={styles.time}>{fmt(next.time)}</Text>
            </View>
            <View style={[styles.rowBetween, { marginTop: 12 }]}>
              <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
                <View style={styles.pillIcon}>
                  <Ionicons name="medkit" size={20} color="#fff" />
                </View>
                <View>
                  <Text style={styles.medName}>{next.med.name}</Text>
                  <Text style={styles.muted}>{next.med.dose}</Text>
                </View>
              </View>
              <Pressable onPress={announce} hitSlop={10}>
                <Ionicons name="volume-high" size={22} color={theme.primary} />
              </Pressable>
            </View>
            <View style={{ height: 12 }} />
            <Button label="Take Now" onPress={() => markDose(next.med.id, next.time, "taken")} />
          </Card>
        ) : null}

        <SectionTitle title="Quick actions" />
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 16 }}>
          {QUICK.map((q) => (
            <Pressable key={q.label} style={styles.quick} onPress={() => router.push(q.href as never)}>
              <Ionicons name={q.icon as never} size={24} color={q.color} />
              <Text style={styles.quickLabel}>{q.label}</Text>
            </Pressable>
          ))}
        </ScrollView>

        <SectionTitle title="Today's Schedule" action="See All" onAction={() => router.push("/history")} />
        <Card>
          {schedule.map((s, i) => {
            const status = doseStatus(s.med.id, s.time);
            return (
              <View key={`${s.med.id}-${s.time}`} style={[styles.scheduleRow, i > 0 && styles.divider]}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.time}>{fmt(s.time)}</Text>
                  <Text style={styles.medName}>{s.med.name}</Text>
                  <Text style={styles.muted}>{s.med.dose}</Text>
                </View>
                <Pressable
                  onPress={() => markDose(s.med.id, s.time, status === "taken" ? "missed" : "taken")}
                  hitSlop={10}
                >
                  <Ionicons
                    name={status === "taken" ? "checkmark-circle" : status === "missed" ? "close-circle" : "ellipse-outline"}
                    size={28}
                    color={status === "taken" ? theme.green : status === "missed" ? theme.red : theme.muted}
                  />
                </Pressable>
              </View>
            );
          })}
        </Card>

        <Card>
          <SectionTitle title="High Quality Voice Reminder" action="Settings" onAction={() => router.push("/voice")} />
          <Text style={styles.muted}>All languages supported — currently {voice.language}.</Text>
          <View style={{ height: 12 }} />
          <Button label="Play sample reminder" icon="volume-high" color={theme.purple} onPress={announce} />
        </Card>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  header: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 16 },
  hello: { color: theme.muted, fontSize: 14 },
  name: { color: theme.text, fontSize: 22, fontWeight: "800" },
  rowBetween: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  muted: { color: theme.muted, fontSize: 12 },
  time: { color: theme.text, fontWeight: "700", fontSize: 13 },
  medName: { color: theme.text, fontWeight: "700", fontSize: 15 },
  pillIcon: { width: 42, height: 42, borderRadius: 12, backgroundColor: theme.primary, alignItems: "center", justifyContent: "center" },
  quick: {
    width: 92,
    height: 92,
    backgroundColor: theme.card,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: theme.border,
    padding: 10,
    marginRight: 10,
    justifyContent: "space-between",
  },
  quickLabel: { color: theme.text, fontSize: 11, fontWeight: "600" },
  scheduleRow: { flexDirection: "row", alignItems: "center", paddingVertical: 12 },
  divider: { borderTopWidth: 1, borderTopColor: theme.border },
});
