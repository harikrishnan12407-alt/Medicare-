import React from "react";
import { Pressable, ScrollView, StyleSheet, Switch, Text, TextInput, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useApp } from "../../src/store";
import { Card, SectionTitle } from "../../src/components/UI";
import { theme } from "../../src/theme";
import { SIZE_OPTIONS } from "../../src/textScale";

export default function Profile() {
  const router = useRouter();
  const { userName, setUserName, age, setAge, textScale, setTextScaleValue, fallDetectionOn, setFallDetectionOn, voice, contacts } = useApp();

  const links = [
    { label: "Voice reminder settings", icon: "volume-high", href: "/voice", hint: voice.language },
    { label: "Family & emergency contacts", icon: "people", href: "/contacts", hint: `${contacts.length} saved` },
    { label: "Fall detection", icon: "walk", href: "/fall", hint: fallDetectionOn ? "On" : "Off" },
    { label: "Reports", icon: "bar-chart", href: "/reports", hint: "This month" },
  ] as const;

  return (
    <ScrollView style={{ backgroundColor: theme.bg }} contentContainerStyle={{ padding: 16 }}>
      <SectionTitle title="Your profile" />
      <Card>
        <Text style={styles.label}>Name</Text>
        <TextInput value={userName} onChangeText={setUserName} style={styles.input} placeholderTextColor={theme.muted} />
        <Text style={[styles.label, { marginTop: 12 }]}>Age</Text>
        <TextInput
          value={age ? String(age) : ""}
          onChangeText={(t) => setAge(parseInt(t.replace(/[^0-9]/g, ""), 10) || 0)}
          keyboardType="number-pad"
          maxLength={3}
          style={styles.input}
          placeholderTextColor={theme.muted}
        />
      </Card>

      <Card>
        <Text style={styles.label}>Text size</Text>
        <Text style={styles.hint}>Makes every screen easier to read.</Text>
        <View style={{ flexDirection: "row", gap: 8, marginTop: 10 }}>
          {SIZE_OPTIONS.map((o) => (
            <Pressable
              key={o.value}
              onPress={() => setTextScaleValue(o.value)}
              style={{
                flex: 1, alignItems: "center", paddingVertical: 10, borderRadius: 12, borderWidth: 1,
                borderColor: textScale === o.value ? theme.primary : theme.border,
                backgroundColor: textScale === o.value ? theme.cardAlt : "transparent",
              }}
            >
              <Text style={{ color: theme.text, fontWeight: "700" }}>Aa</Text>
              <Text style={{ color: theme.muted, fontSize: 10 }}>{o.label}</Text>
            </Pressable>
          ))}
        </View>
      </Card>

      <Card>
        <View style={styles.row}>
          <Text style={styles.label}>Fall detection monitoring</Text>
          <Switch value={fallDetectionOn} onValueChange={setFallDetectionOn} trackColor={{ true: theme.green }} />
        </View>
        <Text style={styles.hint}>Monitors 24/7 using the phone's motion sensors.</Text>
      </Card>

      <Card>
        {links.map((l, i) => (
          <Pressable key={l.label} style={[styles.linkRow, i > 0 && styles.divider]} onPress={() => router.push(l.href as never)}>
            <Ionicons name={l.icon as never} size={20} color={theme.primary} />
            <Text style={[styles.label, { flex: 1 }]}>{l.label}</Text>
            <Text style={styles.hint}>{l.hint}</Text>
            <Ionicons name="chevron-forward" size={18} color={theme.muted} />
          </Pressable>
        ))}
      </Card>

      <Card>
        <Text style={styles.hint}>
          Your data stays on this device. Reminders, fall detection and the voice reminder work fully offline.
        </Text>
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  label: { color: theme.text, fontWeight: "700", fontSize: 14 },
  hint: { color: theme.muted, fontSize: 12 },
  input: {
    marginTop: 8,
    backgroundColor: theme.cardAlt,
    borderRadius: 10,
    padding: 12,
    color: theme.text,
    borderWidth: 1,
    borderColor: theme.border,
  },
  row: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 6 },
  linkRow: { flexDirection: "row", alignItems: "center", gap: 10, paddingVertical: 14 },
  divider: { borderTopWidth: 1, borderTopColor: theme.border },
});
