import React, { useState } from "react";
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useApp } from "../src/store";
import { Button, Card } from "../src/components/UI";
import { theme } from "../src/theme";
import { patternToTimes } from "../src/prescription";

const PATTERNS = ["1-0-0", "0-1-0", "0-0-1", "1-0-1", "1-1-1"];

export default function AddMedicine() {
  const { addMedicine, medicines, removeMedicine } = useApp();
  const router = useRouter();
  const [name, setName] = useState("");
  const [dose, setDose] = useState("1 Tablet");
  const [pattern, setPattern] = useState("1-0-1");
  const [note, setNote] = useState("After Food");

  const submit = () => {
    if (!name.trim()) return;
    addMedicine({ name: name.trim(), dose, form: dose.includes("Capsule") ? "Capsule" : "Tablet", times: patternToTimes(pattern), note });
    router.replace("/");
  };

  return (
    <ScrollView style={{ backgroundColor: theme.bg }} contentContainerStyle={{ padding: 16 }}>
      <Card>
        <Text style={styles.label}>Medicine name</Text>
        <TextInput placeholder="e.g. Paracetamol 650mg" placeholderTextColor={theme.muted} value={name} onChangeText={setName} style={styles.input} />
        <Text style={styles.label}>Dose</Text>
        <TextInput value={dose} onChangeText={setDose} style={styles.input} placeholderTextColor={theme.muted} />
        <Text style={styles.label}>Timing pattern (morning-noon-night)</Text>
        <View style={styles.patterns}>
          {PATTERNS.map((p) => (
            <Pressable key={p} onPress={() => setPattern(p)} style={[styles.chip, pattern === p && styles.chipActive]}>
              <Text style={[styles.chipText, pattern === p && { color: "#fff" }]}>{p}</Text>
            </Pressable>
          ))}
        </View>
        <Text style={styles.label}>Note</Text>
        <TextInput value={note} onChangeText={setNote} style={styles.input} placeholderTextColor={theme.muted} />
        <View style={{ height: 14 }} />
        <Button label="Save & schedule reminders" onPress={submit} icon="alarm" />
      </Card>

      <Card>
        <Text style={styles.label}>Your medicines</Text>
        {medicines.map((m) => (
          <View key={m.id} style={styles.row}>
            <Ionicons name="medkit" size={18} color={theme.primary} />
            <View style={{ flex: 1 }}>
              <Text style={styles.name}>{m.name}</Text>
              <Text style={styles.muted}>{m.times.join(", ")} · {m.note ?? ""}</Text>
            </View>
            <Pressable onPress={() => removeMedicine(m.id)} hitSlop={8}>
              <Ionicons name="trash-outline" size={18} color={theme.muted} />
            </Pressable>
          </View>
        ))}
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  label: { color: theme.text, fontWeight: "700", marginTop: 12, marginBottom: 6 },
  input: { backgroundColor: theme.cardAlt, borderRadius: 10, padding: 12, color: theme.text, borderWidth: 1, borderColor: theme.border },
  patterns: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  chip: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 999, backgroundColor: theme.cardAlt, borderWidth: 1, borderColor: theme.border },
  chipActive: { backgroundColor: theme.primary, borderColor: theme.primary },
  chipText: { color: theme.muted, fontWeight: "700", fontSize: 13 },
  row: { flexDirection: "row", alignItems: "center", gap: 10, paddingVertical: 10 },
  name: { color: theme.text, fontWeight: "600" },
  muted: { color: theme.muted, fontSize: 12 },
});
