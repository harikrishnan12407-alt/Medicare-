import React, { useState } from "react";
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useApp } from "../src/store";
import { Button, Card } from "../src/components/UI";
import { theme } from "../src/theme";
import { callContact } from "../src/emergency";

export default function Contacts() {
  const { contacts, addContact, removeContact } = useApp();
  const [name, setName] = useState("");
  const [relation, setRelation] = useState("");
  const [phone, setPhone] = useState("");

  const submit = () => {
    if (!name.trim() || !phone.trim()) return;
    addContact({ name: name.trim(), relation: relation.trim() || "Family", phone: phone.trim() });
    setName("");
    setRelation("");
    setPhone("");
  };

  return (
    <ScrollView style={{ backgroundColor: theme.bg }} contentContainerStyle={{ padding: 16 }}>
      <Card>
        {contacts.map((c, i) => (
          <View key={c.id} style={[styles.row, i > 0 && styles.divider]}>
            <View style={styles.avatar}>
              <Text style={styles.avatarText}>{c.name.charAt(0)}</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.name}>{c.name}</Text>
              <Text style={styles.muted}>{c.phone} · {c.relation}</Text>
            </View>
            <Pressable onPress={() => callContact(c.phone)} style={styles.callBtn}>
              <Ionicons name="call" size={18} color="#fff" />
            </Pressable>
            <Pressable onPress={() => removeContact(c.id)} hitSlop={8} style={{ marginLeft: 10 }}>
              <Ionicons name="trash-outline" size={18} color={theme.muted} />
            </Pressable>
          </View>
        ))}
      </Card>

      <Card>
        <Text style={styles.name}>Add contact</Text>
        <TextInput placeholder="Name" placeholderTextColor={theme.muted} value={name} onChangeText={setName} style={styles.input} />
        <TextInput placeholder="Relation (Mom, Doctor…)" placeholderTextColor={theme.muted} value={relation} onChangeText={setRelation} style={styles.input} />
        <TextInput
          placeholder="Phone number"
          placeholderTextColor={theme.muted}
          value={phone}
          onChangeText={setPhone}
          keyboardType="phone-pad"
          style={styles.input}
        />
        <View style={{ height: 10 }} />
        <Button label="Add Contact" color={theme.purple} icon="add" onPress={submit} />
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: "row", alignItems: "center", gap: 12, paddingVertical: 12 },
  divider: { borderTopWidth: 1, borderTopColor: theme.border },
  avatar: { width: 40, height: 40, borderRadius: 20, backgroundColor: theme.cardAlt, alignItems: "center", justifyContent: "center" },
  avatarText: { color: theme.text, fontWeight: "800" },
  name: { color: theme.text, fontWeight: "700" },
  muted: { color: theme.muted, fontSize: 12 },
  callBtn: { width: 38, height: 38, borderRadius: 19, backgroundColor: theme.green, alignItems: "center", justifyContent: "center" },
  input: {
    backgroundColor: theme.cardAlt,
    borderRadius: 10,
    padding: 12,
    color: theme.text,
    borderWidth: 1,
    borderColor: theme.border,
    marginTop: 10,
  },
});
