import React from "react";
import { Pressable, ScrollView, StyleSheet, Switch, Text, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useApp } from "../src/store";
import { Button, Card } from "../src/components/UI";
import { theme } from "../src/theme";
import { LANGUAGES } from "../src/languages";
import { speak, stopSpeaking } from "../src/voice";

export default function VoiceScreen() {
  const { voice, setVoice, medicines } = useApp();
  const medName = medicines[0]?.name ?? "Paracetamol 650mg";
  const active = LANGUAGES.find((l) => l.label === voice.language) ?? LANGUAGES[1];

  return (
    <ScrollView style={{ backgroundColor: theme.bg }} contentContainerStyle={{ padding: 16 }}>
      <Card>
        <Text style={styles.title}>High quality voice reminder</Text>
        <Text style={styles.body}>{LANGUAGES.length}+ languages supported, works offline.</Text>
        <View style={styles.langs}>
          {LANGUAGES.map((l) => {
            const on = l.label === voice.language;
            return (
              <Pressable
                key={l.code}
                onPress={() => setVoice({ ...voice, language: l.label, languageCode: l.code })}
                style={[styles.lang, on && styles.langActive]}
              >
                <Text style={[styles.langNative, on && { color: "#fff" }]}>{l.native}</Text>
                <Text style={[styles.langLabel, on && { color: "#fff" }]}>{l.label}</Text>
              </Pressable>
            );
          })}
        </View>
      </Card>

      <Card>
        <Text style={styles.title}>Preview — {active.label}</Text>
        <Text style={styles.sample}>{active.sample(medName)}</Text>
        <View style={{ height: 12 }} />
        <Button label="Play" icon="volume-high" color={theme.purple} onPress={() => speak(active.sample(medName), voice)} />
        <View style={{ height: 8 }} />
        <Button label="Stop" outline color={theme.muted} onPress={stopSpeaking} />
      </Card>

      <Card>
        <Text style={styles.title}>Voice settings</Text>
        <View style={styles.row}>
          <Ionicons name="person" size={18} color={theme.primary} />
          <Text style={styles.label}>Voice type</Text>
          <Pressable onPress={() => setVoice({ ...voice, voiceType: voice.voiceType === "Female" ? "Male" : "Female" })}>
            <Text style={styles.value}>{voice.voiceType}</Text>
          </Pressable>
        </View>
        <View style={styles.row}>
          <Ionicons name="volume-high" size={18} color={theme.primary} />
          <Text style={styles.label}>Volume</Text>
          <Pressable onPress={() => setVoice({ ...voice, volume: voice.volume >= 200 ? 50 : voice.volume + 50 })}>
            <Text style={styles.value}>{voice.volume}%</Text>
          </Pressable>
        </View>
        {[
          ["Repeat until confirmed", "repeatUntilConfirmed"],
          ["Elder friendly (loud, slow voice)", "elderFriendly"],
          ["Use offline voice", "offlineVoice"],
        ].map(([label, key]) => (
          <View key={key} style={styles.row}>
            <Text style={[styles.label, { marginLeft: 0 }]}>{label}</Text>
            <Switch
              value={voice[key as "elderFriendly"]}
              onValueChange={(v) => setVoice({ ...voice, [key]: v })}
              trackColor={{ true: theme.primary }}
            />
          </View>
        ))}
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  title: { color: theme.text, fontWeight: "800", fontSize: 16, marginBottom: 6 },
  body: { color: theme.muted, fontSize: 13 },
  langs: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginTop: 12 },
  lang: { paddingHorizontal: 12, paddingVertical: 8, borderRadius: 10, backgroundColor: theme.cardAlt, borderWidth: 1, borderColor: theme.border },
  langActive: { backgroundColor: theme.purple, borderColor: theme.purple },
  langNative: { color: theme.text, fontWeight: "700" },
  langLabel: { color: theme.muted, fontSize: 11 },
  sample: { color: theme.text, lineHeight: 22, marginTop: 8 },
  row: { flexDirection: "row", alignItems: "center", gap: 10, paddingVertical: 12, justifyContent: "space-between" },
  label: { color: theme.text, flex: 1, fontWeight: "600", marginLeft: 4 },
  value: { color: theme.primary, fontWeight: "700" },
});
