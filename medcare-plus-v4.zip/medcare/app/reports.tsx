import React, { useMemo } from "react";
import { ScrollView, StyleSheet, Text, View } from "react-native";
import { useApp } from "../src/store";
import { Card, StatBox } from "../src/components/UI";
import { theme } from "../src/theme";

export default function Reports() {
  const { logs, medicines } = useApp();

  const stats = useMemo(() => {
    const taken = logs.filter((l) => l.status === "taken").length;
    const missed = logs.filter((l) => l.status === "missed").length;
    const total = taken + missed;
    return {
      adherence: total ? Math.round((taken / total) * 100) : 0,
      onTime: total ? Math.round((taken / total) * 100) : 0,
      missed,
      totalMeds: medicines.reduce((a, m) => a + m.times.length, 0) * 30,
    };
  }, [logs, medicines]);

  const days = useMemo(() => {
    const map: Record<string, { taken: number; missed: number }> = {};
    for (const l of logs) {
      map[l.date] ||= { taken: 0, missed: 0 };
      if (l.status === "taken") map[l.date].taken++;
      else map[l.date].missed++;
    }
    return Object.entries(map).sort((a, b) => a[0].localeCompare(b[0])).slice(-14);
  }, [logs]);

  const max = Math.max(1, ...days.map(([, d]) => d.taken + d.missed));

  return (
    <ScrollView style={{ backgroundColor: theme.bg }} contentContainerStyle={{ padding: 16 }}>
      <View style={styles.grid}>
        <StatBox label="Medicines Taken" value={`${stats.adherence}%`} color={theme.green} />
        <StatBox label="On Time" value={`${stats.onTime}%`} color={theme.primary} />
      </View>
      <View style={[styles.grid, { marginTop: 12, marginBottom: 16 }]}>
        <StatBox label="Missed Doses" value={`${stats.missed}`} color={theme.red} />
        <StatBox label="Doses / month" value={`${stats.totalMeds}`} color={theme.amber} />
      </View>

      <Card>
        <Text style={styles.title}>Last 14 days</Text>
        <View style={styles.chart}>
          {days.length === 0 ? <Text style={styles.muted}>No data yet.</Text> : null}
          {days.map(([date, d]) => (
            <View key={date} style={styles.barGroup}>
              <View style={[styles.bar, { height: (d.taken / max) * 90 + 2, backgroundColor: theme.green }]} />
              <View style={[styles.bar, { height: (d.missed / max) * 90 + 2, backgroundColor: theme.red }]} />
            </View>
          ))}
        </View>
        <View style={styles.legend}>
          <View style={[styles.dot, { backgroundColor: theme.green }]} />
          <Text style={styles.muted}>Taken</Text>
          <View style={[styles.dot, { backgroundColor: theme.red, marginLeft: 16 }]} />
          <Text style={styles.muted}>Missed</Text>
        </View>
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  grid: { flexDirection: "row", gap: 12 },
  title: { color: theme.text, fontWeight: "800", marginBottom: 14 },
  chart: { flexDirection: "row", alignItems: "flex-end", gap: 8, height: 110 },
  barGroup: { flexDirection: "row", gap: 2, alignItems: "flex-end" },
  bar: { width: 6, borderRadius: 3 },
  legend: { flexDirection: "row", alignItems: "center", gap: 6, marginTop: 14 },
  dot: { width: 10, height: 10, borderRadius: 5 },
  muted: { color: theme.muted, fontSize: 12 },
});
