import React, { useEffect, useRef, useState } from "react";
import { Pressable, ScrollView, StyleSheet, Text, Vibration, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useApp } from "../src/store";
import { Card } from "../src/components/UI";
import { theme } from "../src/theme";
import { callContact, sendWhatsApp, triggerFullSos, buildSosMessage, getLocationLink } from "../src/emergency";
import { speak } from "../src/voice";

const HOLD_MS = 2000;

export default function Sos() {
  const { contacts, userName, voice } = useApp();
  const [progress, setProgress] = useState(0);
  const [sent, setSent] = useState<string | null>(null);
  const hold = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => () => { if (hold.current) clearInterval(hold.current); }, []);

  const start = () => {
    const startedAt = Date.now();
    hold.current = setInterval(async () => {
      const p = Math.min(1, (Date.now() - startedAt) / HOLD_MS);
      setProgress(p);
      if (p >= 1) {
        clearInterval(hold.current!);
        Vibration.vibrate([0, 600, 200, 600]);
        speak("Sending emergency alert to your contacts now.", voice);
        const { link } = await triggerFullSos(userName, contacts);
        setSent(link);
        setProgress(0);
      }
    }, 50);
  };

  const stop = () => {
    if (hold.current) clearInterval(hold.current);
    setProgress(0);
  };

  const whatsappAll = async () => {
    const link = await getLocationLink();
    const msg = buildSosMessage(userName, link);
    if (contacts[0]) sendWhatsApp(contacts[0].phone, msg);
  };

  return (
    <ScrollView style={{ backgroundColor: theme.bg }} contentContainerStyle={{ padding: 16 }}>
      <Card style={{ borderColor: theme.red, alignItems: "center" }}>
        <Text style={styles.title}>SOS Emergency</Text>
        <Text style={styles.sub}>Press & hold for help</Text>
        <Pressable onPressIn={start} onPressOut={stop} style={styles.sosOuter}>
          <View style={[styles.sosInner, { transform: [{ scale: 1 + progress * 0.08 }] }]}>
            <Text style={styles.sosText}>SOS</Text>
          </View>
        </Pressable>
        <Text style={styles.body}>
          Instant call, live location & SMS sent to your emergency contacts with a loud alert.
        </Text>
        <Pressable style={styles.loud} onPress={() => { Vibration.vibrate([0, 900, 200, 900]); speak("Emergency! Please help!", { ...voice, volume: 200 }); }}>
          <Ionicons name="volume-high" size={18} color="#fff" />
          <Text style={styles.loudText}>High Sound Alert</Text>
        </Pressable>
      </Card>

      {sent ? (
        <Card style={{ borderColor: theme.green }}>
          <Text style={styles.okTitle}>Alert sent</Text>
          <Text style={styles.body}>Live location shared: {sent}</Text>
        </Card>
      ) : null}

      <Card>
        <Text style={styles.cardTitle}>What happens when you trigger SOS</Text>
        {[
          ["volume-high", "High alert sound"],
          ["time", "15 second countdown for fall alerts"],
          ["call", "Instant SOS call to first contact"],
          ["navigate", "Live location SMS"],
          ["logo-whatsapp", "WhatsApp alert"],
          ["people", "Alert to all contacts"],
        ].map(([icon, label]) => (
          <View key={label} style={styles.row}>
            <Ionicons name={icon as never} size={18} color={theme.red} />
            <Text style={styles.rowText}>{label}</Text>
          </View>
        ))}
      </Card>

      <Card>
        <Text style={styles.cardTitle}>Quick contact</Text>
        {contacts.map((c) => (
          <View key={c.id} style={styles.contactRow}>
            <View style={{ flex: 1 }}>
              <Text style={styles.rowText}>{c.name}</Text>
              <Text style={styles.sub}>{c.phone}</Text>
            </View>
            <Pressable onPress={() => callContact(c.phone)} style={styles.iconBtn}>
              <Ionicons name="call" size={18} color="#fff" />
            </Pressable>
          </View>
        ))}
        <Pressable style={[styles.loud, { backgroundColor: theme.green, marginTop: 12 }]} onPress={whatsappAll}>
          <Ionicons name="logo-whatsapp" size={18} color="#fff" />
          <Text style={styles.loudText}>Send WhatsApp alert</Text>
        </Pressable>
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  title: { color: theme.red, fontSize: 22, fontWeight: "800" },
  sub: { color: theme.muted, fontSize: 12, marginTop: 4 },
  sosOuter: { marginVertical: 22, alignItems: "center", justifyContent: "center" },
  sosInner: {
    width: 170,
    height: 170,
    borderRadius: 85,
    backgroundColor: theme.red,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 6,
    borderColor: "#FF8A8A55",
  },
  sosText: { color: "#fff", fontSize: 44, fontWeight: "900" },
  body: { color: theme.muted, textAlign: "center", fontSize: 13, lineHeight: 19 },
  loud: {
    flexDirection: "row",
    gap: 8,
    backgroundColor: theme.red,
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 12,
    alignItems: "center",
    marginTop: 16,
  },
  loudText: { color: "#fff", fontWeight: "700" },
  okTitle: { color: theme.green, fontWeight: "800", marginBottom: 6 },
  cardTitle: { color: theme.text, fontWeight: "700", marginBottom: 10 },
  row: { flexDirection: "row", alignItems: "center", gap: 10, paddingVertical: 8 },
  rowText: { color: theme.text, fontSize: 14, fontWeight: "600" },
  contactRow: { flexDirection: "row", alignItems: "center", paddingVertical: 10 },
  iconBtn: { width: 38, height: 38, borderRadius: 19, backgroundColor: theme.green, alignItems: "center", justifyContent: "center" },
});
