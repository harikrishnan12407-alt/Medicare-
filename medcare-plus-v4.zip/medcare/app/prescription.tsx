import React, { useRef, useState } from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { CameraView, useCameraPermissions } from "expo-camera";
import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useApp } from "../src/store";
import { Button, Card } from "../src/components/UI";
import { theme } from "../src/theme";
import { extractMedicines, type Extracted } from "../src/prescription";

export default function Prescription() {
  const [permission, requestPermission] = useCameraPermissions();
  const [items, setItems] = useState<Extracted[] | null>(null);
  const [busy, setBusy] = useState(false);
  const cam = useRef<CameraView>(null);
  const { addMedicine } = useApp();
  const router = useRouter();

  if (!permission?.granted) {
    return (
      <View style={styles.center}>
        <Ionicons name="document-text-outline" size={48} color={theme.muted} />
        <Text style={styles.body}>Camera access is needed to scan a prescription.</Text>
        <Button label="Allow camera" onPress={requestPermission} color={theme.purple} />
      </View>
    );
  }

  const capture = async () => {
    setBusy(true);
    const photo = await cam.current?.takePictureAsync({ quality: 0.6, base64: false });
    const result = await extractMedicines(photo?.uri);
    setItems(result);
    setBusy(false);
  };

  return (
    <ScrollView style={{ backgroundColor: theme.bg }} contentContainerStyle={{ padding: 16 }}>
      <Card>
        <Text style={styles.title}>Prescription Scan</Text>
        <Text style={styles.body}>Place the prescription flat and capture it to extract medicines.</Text>
        <View style={styles.camWrap}>
          <CameraView ref={cam} style={{ flex: 1 }} />
        </View>
        <View style={{ height: 12 }} />
        <Button label={busy ? "Reading prescription…" : "Capture & extract"} onPress={capture} color={theme.purple} icon="scan" />
      </Card>

      {items ? (
        <Card>
          <Text style={styles.title}>Extracted Medicines</Text>
          {items.map((m, i) => (
            <View key={m.name} style={[styles.row, i > 0 && styles.divider]}>
              <Ionicons name="medkit" size={18} color={theme.green} />
              <View style={{ flex: 1 }}>
                <Text style={styles.name}>{m.name}</Text>
                <Text style={styles.body}>{m.pattern} ({m.note})</Text>
              </View>
            </View>
          ))}
          <View style={{ height: 12 }} />
          <Button
            label="Add All to Schedule"
            color={theme.purple}
            onPress={() => {
              items.forEach((m) =>
                addMedicine({ name: m.name, dose: "1 Dose", form: "Tablet", times: m.times, note: m.note })
              );
              router.replace("/");
            }}
          />
          <View style={{ height: 8 }} />
          <Pressable onPress={() => setItems(null)}>
            <Text style={styles.again}>Scan again</Text>
          </Pressable>
        </Card>
      ) : null}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, backgroundColor: theme.bg, alignItems: "center", justifyContent: "center", padding: 24, gap: 14 },
  title: { color: theme.text, fontWeight: "800", fontSize: 16, marginBottom: 6 },
  body: { color: theme.muted, fontSize: 13 },
  camWrap: { height: 280, borderRadius: 14, overflow: "hidden", marginTop: 12, backgroundColor: "#000" },
  row: { flexDirection: "row", alignItems: "center", gap: 10, paddingVertical: 12 },
  divider: { borderTopWidth: 1, borderTopColor: theme.border },
  name: { color: theme.text, fontWeight: "700" },
  again: { color: theme.primary, textAlign: "center", fontWeight: "600" },
});
