# MedCare+ — Medicine Reminder & Health Safety

A complete React Native (Expo) app: medicine reminders with multilingual voice,
medicine barcode scanner, prescription scan, 24/7 fall detection, SOS emergency
(call + live location SMS + WhatsApp), health dashboard, history and reports.

Package: `com.medcare.plus` · App name: MedCare+

---

## 1. Open the project

Unzip, then open the folder in any IDE (Antigravity, VS Code, Cursor, WebStorm).

```bash
npm install
npx expo start
```

Scan the QR code with **Expo Go** on Android for a quick look. Note: fall
detection, SMS, calling and exact alarms only work fully in a real build (step 2).

## 2. Get the APK (cloud build — no Android Studio needed)

```bash
npm install -g eas-cli
eas login                 # free Expo account
eas build:configure       # writes your own projectId into app.json
npm run build:apk         # = eas build -p android --profile preview
```

EAS builds on Expo's servers and gives you a download link for
`medcare-plus.apk`. Install it on any Android phone (allow "install from
unknown sources").

The `preview` profile in `eas.json` is already set to `buildType: "apk"`, so
you get an installable APK rather than an AAB. For Play Store upload later use:

```bash
eas build -p android --profile production
```

### Building locally instead

```bash
npx expo prebuild -p android
cd android && ./gradlew assembleRelease
# APK at android/app/build/outputs/apk/release/app-release.apk
```

## 3. Project structure

```
app/                     screens (expo-router file based routing)
  (tabs)/index.tsx       Home — next medicine, today's schedule, quick actions
  (tabs)/history.tsx     Taken / Missed history
  (tabs)/health.tsx      Health dashboard
  (tabs)/profile.tsx     Profile and settings
  sos.tsx                SOS press & hold, loud alert, quick call
  scanner.tsx            Medicine barcode scanner
  prescription.tsx       Prescription capture + medicine extraction
  fall.tsx               Fall detection status and settings
  contacts.tsx           Family & emergency contacts
  add-medicine.tsx       Add medicine, 1-0-1 dosage patterns
  voice.tsx              Language picker + voice settings
  reports.tsx            Adherence stats and 14-day chart
src/
  store.tsx              App state, persisted with AsyncStorage (offline)
  notifications.ts       Daily repeating medicine alarms
  voice.ts               Text-to-speech in 12 Indian languages
  fallDetection.ts       Free-fall → impact → stillness algorithm
  emergency.ts           Location, SOS SMS, call, WhatsApp
  prescription.ts        Dosage pattern parsing + optional cloud OCR hook
  medicineDb.ts          Barcode → medicine lookup
  languages.ts           Language list and native reminder sentences
```

## 4. Permissions used

Camera (scanning), notifications + exact alarms (reminders), location (SOS),
SMS and phone (emergency alerts), motion sensors (fall detection).
Android 13+ asks for notification permission on first launch.

## 5. Optional: real prescription OCR

The prescription screen works offline with the built-in parser. To use a cloud
OCR service, create `.env` with:

```
EXPO_PUBLIC_OCR_ENDPOINT=https://your-ocr-endpoint/extract
```

It should accept a multipart `file` and return
`{ "medicines": [{ "name": "...", "pattern": "1-0-1", "note": "After Food" }] }`.

## 6. Icons and splash

Drop `icon.png` (1024×1024), `adaptive-icon.png` and `splash.png` into `assets/`
and reference them in `app.json` before the production build.

---

**Medical disclaimer:** MedCare+ is a reminder and safety aid, not a medical
device. Fall detection and SOS depend on sensors, network and permissions and
can miss events. Always keep a human backup plan for emergencies.

## Background running (added in v3)

The app now keeps working in the background:

- **Medicine reminders** fire even when the app is closed — they use the phone's system alarm.
- **A background task** runs every ~15 minutes (and after every phone reboot) to re-schedule any reminders that were missed.
- For best results on Android: Settings → Apps → MedCare+ → Battery → set to **Unrestricted**, so the phone doesn't put the app to sleep.

Note: fall detection needs the app open (or recently opened) to read motion sensors continuously — Android does not allow constant sensor access to fully closed apps. Keep the app open on the Fall Detection screen for 24/7 monitoring.

## Updating the app after changes

After editing code, run:
```
git add .
git commit -m "My update"
npm run build:apk
```
Then install the new APK. The APK does not update by itself.

## New in v4
- Stylish animated splash screen on every launch.
- First launch asks your name and age — no demo data; everything starts empty.
- Text size (Normal / Large / Extra Large / Huge), suggested by age, changeable in Profile.
- Fall detection keeps running in the background with a "MedCare+ fall detection is on" notification.
  When asked for location, choose **"Allow all the time"**, and set Battery to **Unrestricted**.
